package com.example.womapp_alfa

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Intent
import android.net.Uri

class MainActivity : AppCompatActivity() {  //classe Schermo principale

    override fun onCreate(savedInstanceState: Bundle?) { //Funzione avvio attività inizializza la schermata
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startButton.setOnClickListener {                         //Gestione evento click bottone
            startActivity(Intent(this, logInActivity::class.java))     //avvio attività di login / signin
        }



        instagramButton.setOnClickListener {                            //Gestione evento click del bottone
            val url = "https://www.instagram.com/samuelevilla.exe/"     //variabile stringa contenete URL
            val instagram = Intent(Intent.ACTION_VIEW)                  //assegnazione alla variabile azione di visualizzazione attività
            instagram.data = Uri.parse(url)                             //assegnazione alla proprietà dato l'url
            startActivity(instagram)                                   //avvio ricerca su internet
        }

        facebookbutton.setOnClickListener {
            val url = "https://www.facebook.com/profile.php?id=100006418575399"
            val facebook = Intent(Intent.ACTION_VIEW)
            facebook.data = Uri.parse(url)
            startActivity(facebook)
        }

        twitterButton.setOnClickListener {
            val url = "https://twitter.com/explore"
            val twitter = Intent(Intent.ACTION_VIEW)
            twitter.data = Uri.parse(url)
            startActivity(twitter)
        }

    }
}
