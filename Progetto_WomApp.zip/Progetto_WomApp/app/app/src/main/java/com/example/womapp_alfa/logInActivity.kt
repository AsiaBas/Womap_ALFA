package com.example.womapp_alfa

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class logInActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)
    }
}
